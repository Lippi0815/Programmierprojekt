/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui;

import client.Controller;
import client.Controller.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 *
 * @author t.lippert
 */
public class ClientGUI extends javax.swing.JFrame {

    static Controller controller;
    ChatRoomTest[] chatrooms = new ChatRoomTest[1000000];
    public static String DELIMITER = "-&/";

    public ClientGUI(Controller controller) {
        this.controller = controller;
        initComponents();
        myInitComponents();

    }

    private void myInitComponents() {
        userList.setModel(new DefaultListModel());
        roomList.setModel(new DefaultListModel());
        
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int confirm = JOptionPane.showOptionDialog(
                        null, "Möchtest du die Anwendung wirklich beenden?",
                        "Exit Confirmation", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (confirm == 0) {
                    logOff();
                }
            }
        });
    }
    
    public void logOff() {
        try {
            //benachrichtigt server, dass sich der Client abmeldet und schließt anschließend den outputstream
            controller.getWriter().logOff();
        } catch (IOException ex) {}
        //schließt den InputStream
        controller.getReader().interrupt();
        
        this.dispose();
        for (ChatRoomTest c : chatrooms) {
            if(c != null)c.dispose();
        }
        
        try {
            controller.getServer().close();
        } catch (IOException ex) {}
        controller.interrupt();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        statusPanel = new javax.swing.JPanel();
        nicknameLabel = new javax.swing.JLabel();
        connectionLabel = new javax.swing.JLabel();
        overviewPanel = new javax.swing.JPanel();
        overviewTabbedPane = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        userList = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        roomList = new javax.swing.JList<>();
        mainChatPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        mainChatTextArea = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        mainChatMessageTextField = new javax.swing.JTextField();
        mainChatSendButton = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        userMenu = new javax.swing.JMenu();
        blockUserMenuItem = new javax.swing.JMenuItem();
        unblockUserMenuItem = new javax.swing.JMenuItem();
        privateChatMenuItem = new javax.swing.JMenuItem();
        roomMenu = new javax.swing.JMenu();
        addRoomMenuItem = new javax.swing.JMenuItem();
        editRoomMenuItem = new javax.swing.JMenuItem();
        deleteRoomMenuItem = new javax.swing.JMenuItem();
        joinRoomMenuItem = new javax.swing.JMenuItem();
        optionMenu = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        statusPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Status", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 18))); // NOI18N

        nicknameLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nicknameLabel.setText("Nickname: ");

        connectionLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        connectionLabel.setText("Verbindung: ");

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(nicknameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(connectionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addComponent(nicknameLabel)
                .addGap(18, 18, 18)
                .addComponent(connectionLabel)
                .addGap(0, 14, Short.MAX_VALUE))
        );

        overviewPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Übersicht", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 18))); // NOI18N

        jScrollPane1.setViewportView(userList);

        overviewTabbedPane.addTab("Benutzer", jScrollPane1);

        jScrollPane2.setViewportView(roomList);

        overviewTabbedPane.addTab("Räume", jScrollPane2);

        javax.swing.GroupLayout overviewPanelLayout = new javax.swing.GroupLayout(overviewPanel);
        overviewPanel.setLayout(overviewPanelLayout);
        overviewPanelLayout.setHorizontalGroup(
            overviewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(overviewPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(overviewTabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 429, Short.MAX_VALUE)
                .addContainerGap())
        );
        overviewPanelLayout.setVerticalGroup(
            overviewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(overviewPanelLayout.createSequentialGroup()
                .addComponent(overviewTabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainChatPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Haupt-Chat", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 18))); // NOI18N

        mainChatTextArea.setEditable(false);
        mainChatTextArea.setColumns(20);
        mainChatTextArea.setRows(5);
        jScrollPane3.setViewportView(mainChatTextArea);

        javax.swing.GroupLayout mainChatPanelLayout = new javax.swing.GroupLayout(mainChatPanel);
        mainChatPanel.setLayout(mainChatPanelLayout);
        mainChatPanelLayout.setHorizontalGroup(
            mainChatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainChatPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3)
                .addContainerGap())
        );
        mainChatPanelLayout.setVerticalGroup(
            mainChatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainChatPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 410, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Nachricht senden", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 18))); // NOI18N

        mainChatMessageTextField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        mainChatSendButton.setText("Senden!");
        mainChatSendButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mainChatSendButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainChatMessageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mainChatSendButton, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(mainChatMessageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(mainChatSendButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        userMenu.setText("Benutzer");

        blockUserMenuItem.setText("Benutzer blockieren");
        userMenu.add(blockUserMenuItem);

        unblockUserMenuItem.setText("Benutzer entblockieren");
        userMenu.add(unblockUserMenuItem);

        privateChatMenuItem.setText("Privatchat öffnen");
        userMenu.add(privateChatMenuItem);

        jMenuBar1.add(userMenu);

        roomMenu.setText("Räume");

        addRoomMenuItem.setText("Raum hinzufügen");
        addRoomMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRoomMenuItemActionPerformed(evt);
            }
        });
        roomMenu.add(addRoomMenuItem);

        editRoomMenuItem.setText("Raum bearbeiten");
        editRoomMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editRoomMenuItemActionPerformed(evt);
            }
        });
        roomMenu.add(editRoomMenuItem);

        deleteRoomMenuItem.setText("Raum löschen");
        deleteRoomMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRoomMenuItemActionPerformed(evt);
            }
        });
        roomMenu.add(deleteRoomMenuItem);

        joinRoomMenuItem.setText("Raum beitreten");
        joinRoomMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                joinRoomMenuItemActionPerformed(evt);
            }
        });
        roomMenu.add(joinRoomMenuItem);

        jMenuBar1.add(roomMenu);

        optionMenu.setText("Optionen");
        jMenuBar1.add(optionMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mainChatPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(overviewPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(statusPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(mainChatPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(statusPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(overviewPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mainChatSendButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mainChatSendButtonActionPerformed

        try {
            controller.sendMessageIntoChatroom(1,mainChatMessageTextField.getText(), "String");
        } catch (IOException ex) {}
        
    }//GEN-LAST:event_mainChatSendButtonActionPerformed

    private void addRoomMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRoomMenuItemActionPerformed
        new Thread(() -> {
            try {
                controller.getWriter().sendMessage("3"+TextInputDialog.openWindowAndGetText());
            } catch (IOException ex) {}
        }).start();
    }//GEN-LAST:event_addRoomMenuItemActionPerformed

    private void deleteRoomMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRoomMenuItemActionPerformed
        try {
            controller.getWriter().sendMessage("5"+(roomList.getSelectedIndex()+1));
        } catch (IOException ex) {}
    }//GEN-LAST:event_deleteRoomMenuItemActionPerformed

    private void joinRoomMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_joinRoomMenuItemActionPerformed
        int index = this.roomList.getSelectedIndex();
        
        chatrooms[index]=new ChatRoomTest(index+1, controller.getWriter());
        chatrooms[index].setVisible(true);
        
        try {
            controller.getWriter().sendMessage("6"+(index+1));
        } catch (IOException ex) {}
    }//GEN-LAST:event_joinRoomMenuItemActionPerformed

    private void editRoomMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editRoomMenuItemActionPerformed
        new Thread(() -> {
            try {
                controller.getWriter().sendMessage("9"+(roomList.getSelectedIndex()+1)+DELIMITER+TextInputDialog.openWindowAndGetText());
            } catch (IOException ex) {}
        }).start();
    }//GEN-LAST:event_editRoomMenuItemActionPerformed

    public JTextArea getMainChatTextArea() {
        return mainChatTextArea;
    }

    public JList<String> getUserList() {
        return userList;
    }

    public JList<String> getRoomList() {
        return roomList;
    }
    
    public ChatRoomTest[] getChatrooms(){
        return chatrooms;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientGUI(controller).setVisible(true);
            }
        });
    }

    public void update() throws IOException {
        //Fordert Chatroom-Liste an
        controller.getWriter().sendMessage("2");
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem addRoomMenuItem;
    private javax.swing.JMenuItem blockUserMenuItem;
    private javax.swing.JLabel connectionLabel;
    private javax.swing.JMenuItem deleteRoomMenuItem;
    private javax.swing.JMenuItem editRoomMenuItem;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JMenuItem joinRoomMenuItem;
    private javax.swing.JTextField mainChatMessageTextField;
    private javax.swing.JPanel mainChatPanel;
    private javax.swing.JButton mainChatSendButton;
    private javax.swing.JTextArea mainChatTextArea;
    private javax.swing.JLabel nicknameLabel;
    private javax.swing.JMenu optionMenu;
    private javax.swing.JPanel overviewPanel;
    private javax.swing.JTabbedPane overviewTabbedPane;
    private javax.swing.JMenuItem privateChatMenuItem;
    private javax.swing.JList<String> roomList;
    private javax.swing.JMenu roomMenu;
    private javax.swing.JPanel statusPanel;
    private javax.swing.JMenuItem unblockUserMenuItem;
    private javax.swing.JList<String> userList;
    private javax.swing.JMenu userMenu;
    // End of variables declaration//GEN-END:variables
}
