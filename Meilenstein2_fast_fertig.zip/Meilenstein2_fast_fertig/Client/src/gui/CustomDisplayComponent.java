package gui;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class CustomDisplayComponent extends JPanel {
    private JScrollPane scrollPane;
    private JPanel panel;

    public CustomDisplayComponent() {
        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        scrollPane = new JScrollPane(panel);
        scrollPane.setPreferredSize(new Dimension(400, 400));
        add(scrollPane);
    }

    public void addText(String text) {
        JLabel label = new JLabel(text);
        label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        panel.add(label);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.revalidate();
        panel.repaint();
    }

    public void addImage(byte[] imageBytes) {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes);
            BufferedImage bImage = ImageIO.read(bis);
            ImageIcon icon = new ImageIcon(bImage.getScaledInstance(200, 200, Image.SCALE_SMOOTH));
            JLabel label = new JLabel(icon);
            label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
            panel.add(label);
            panel.add(Box.createRigidArea(new Dimension(0, 5)));
            panel.revalidate();
            panel.repaint();
        } catch (IOException ex) {
            System.err.println("Error: " + ex.getMessage());
        }
    }
}