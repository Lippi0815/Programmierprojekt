/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package client;

import gui.GUIController;
import gui.Warning;
import java.io.IOException;
import java.net.Socket;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import threads.ClientReadThread;
import threads.ClientWriteThread;

/**
 *
 * @author t.lippert
 */
public class Controller extends Thread{
    
    public String DELIMITER = "-&/";
    
    GUIController guiController;
    ClientReadThread reader;
    ClientWriteThread writer;
    boolean running = true;
    public Socket server;

    public Controller(Socket server) throws IOException{
        this.guiController = new GUIController(this);
        reader = new ClientReadThread(server, this);
        writer = new ClientWriteThread(server);
        this.server = server;
    }
    
    public void run(){
        reader.start();
        writer.start();
    }
    
    public void login(){
        this.guiController.getLoginGUI().setVisible(true);
    }
    
    public void processMessage(String message) throws IOException {
        JList myList;
        DefaultListModel listModel;
        System.out.println(message);
        switch(message.charAt(0)){
            case '0':
                //Wir bekommen Liste aller Clients
                myList = guiController.getClientGUI().getUserList();
                //myList = (JList) ((JScrollPane)ui.getJTabbedPane1().getComponentAt(0)).getViewport().getView();
                listModel = new DefaultListModel();
                for(String user : (message.substring(1, message.length())).split(DELIMITER)){
                    listModel.addElement(user);
                }
                myList.setModel(listModel);
                break;
            case '1':
                //Wir bekommen den Namen eines neu angemeldeten Clients
                myList = guiController.getClientGUI().getUserList();
                //myList = (JList) ((JScrollPane)ui.getJTabbedPane1().getComponentAt(0)).getViewport().getView();
                listModel = (DefaultListModel) myList.getModel();
                String newUser = message.substring(1, message.length());
                listModel.addElement(newUser);
                break;
            case '2':
                //Wir bekommen die Liste aller Chatrooms
                myList = guiController.getClientGUI().getRoomList();
                listModel = new DefaultListModel();
                for(String chatroom : (message.substring(1, message.length())).split(DELIMITER)){
                    listModel.addElement(chatroom);
                }
                myList.setModel(listModel);
                guiController.getClientGUI().repaint();
                break;
            case '3':
                // Benutzeroberfläche aktualisieren
                guiController.getClientGUI().getMainChatTextArea().append(message.substring(1)+"\n");
                //ui.updateUIBasedOnMessage(message.substring(1, message.length()));
                break;
                
            //Nachricht empfangen
            case '4':
                message = message.substring(1);
                System.out.println(message);
                String[] content = message.split(DELIMITER);
                System.out.println("Append message in Chatroom: "+content[1]);
                if(guiController.getClientGUI().getChatrooms()[Integer.parseInt(content[0])-1] != null){
                    System.out.println("Append message in Chatroom "+content[0]);
                    if("String".equals(content[2])){
                        guiController.getClientGUI().getChatrooms()[Integer.parseInt(content[0])-1].getChatArea().addText(content[1]);
                        if("1".equals(content[0])){
                            guiController.getClientGUI().getMainChatTextArea().append(content[1]+"\n");
                        }
                    } else if("Image".equals(content[2])){
                                int lastIndex = content[1].lastIndexOf(':');
        
                        // Schneide den String ab dem Index des letzten ':' ab
                        content[1] = content[1].substring(lastIndex + 1);
                        String[] byteStrings = content[1].split(",");
                        byte[] byteArray = new byte[byteStrings.length];

                        for (int i = 0; i < byteStrings.length; i++) {
                            byteArray[i] = Byte.parseByte(byteStrings[i].trim());
                        }
                        guiController.getClientGUI().getChatrooms()[Integer.parseInt(content[0])-1].getChatArea().addImage(byteArray);
                    }
                    
                }
                System.out.println("Fertig in Chatroom "+content[0]);
                break;
            case '6':
                displayWarning("Achtung! Dies ist eine Verwarnung! \n Bei weiterem Fehlverhalten wirst du \n einen temporären Bann erhalten");
                break;
            case '7':
                displayWarning("Achtung! Dies ist ein temporärer Bann! \n Bei weiterem Fehlverhalten wirst du \n einen permanenten Bann erhalten");
                guiController.getClientGUI().logOff();
                break;
            case '8':
                displayPermaBanWarning();
                guiController.getClientGUI().logOff();
                break;
            case 'x':
                System.out.println("Login Fail");
                //Meldung, dass Login fehlgeschlagen
                this.guiController.getLoginGUI().loginFail();
                break;
            case 'y':
                System.out.println("Login Success");
                //Meldung, dass Login erfolgreich
                this.guiController.getClientGUI().setVisible(true);
                this.guiController.getClientGUI().update();
                this.guiController.getLoginGUI().loginSuccess();
                break;
            default:
                break;
        }
        System.out.println("Anfrage fertig");
    }
    
    public void sendChatroomListQuery() throws IOException{
        writer.sendMessage("2");
    }

    void sendAddChatroomQuery(String s) throws IOException {
        writer.sendMessage("3"+s);
    }

    void sendRemoveChatroomQuery(int selectedIndex) throws IOException {
        writer.sendMessage("5"+(selectedIndex+1));
    }
    
    public void sendMessageIntoChatroom(int chatroomID, String message, String type) throws IOException{
        writer.sendMessage("8"+chatroomID+DELIMITER+message+DELIMITER+type);
    }
    
    public ClientReadThread getReader(){
        return this.reader;
    }
    
    public ClientWriteThread getWriter(){
        return this.writer;
    }

    public GUIController getGuiController() {
        return guiController;
    }
    
    public Socket getServer(){
        return server;
    }

    private void displayWarning(String text) {
        Warning w = new Warning(text);
        w.setVisible(true);
    }

    private void displayPermaBanWarning() {
        Warning w = new Warning("Achtung!\n Du hast einen permanenten Bann erhalten! \nDein Account wird gesperrt");
        w.setVisible(true);
    }
    
    
}
