package threads;


import client.Controller;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;


public class ClientReadThread extends Thread {
    
    String ENDOFSTREAM = "#*+!";
    
    Socket server;
    Controller controller;
    DataInputStream in;
    
    
    
    public ClientReadThread(Socket server, Controller controller) throws IOException{
        this.server = server;
        this.controller = controller;
        this.in = new DataInputStream(server.getInputStream());
    }
    
    @Override
    public void run(){
        try {
        while(true){
            String message = this.readMessage();
            controller.processMessage(message);
        }
            
        } catch (IOException ex) {}
    }

    
    public String readMessage() throws IOException {
    System.out.println("Client liest Nachricht vom Server");
    String message = "";
    
    while (!message.endsWith(ENDOFSTREAM)) {
        message += (char) in.read();
    }
    return message.substring(0, message.length() - ENDOFSTREAM.length());
}
}
