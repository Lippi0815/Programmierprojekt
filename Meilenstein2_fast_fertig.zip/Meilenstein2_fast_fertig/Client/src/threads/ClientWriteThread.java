package threads;



import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author t.lippert
 */
public class ClientWriteThread extends Thread{
    DataOutputStream out;
    String ENDOFSTREAM = "#*+!";
    public String DELIMITER = "-&/";
    
    public ClientWriteThread(Socket server) throws IOException{
        out = new DataOutputStream(server.getOutputStream());
    }


    public void logOff() throws IOException {
        
        //############
        sendMessage("z");
        this.interrupt();
    }
    

    
    public void sendMessage(String message) throws IOException{
        out.write((message+ENDOFSTREAM).getBytes("UTF-8"));
        out.flush();
    }
    
    
}
