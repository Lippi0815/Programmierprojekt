/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package server;

import controller.SuperController;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author t.lippert
 */
public class Server {

    static ArrayList<ServerThread> serverThreads = new ArrayList<ServerThread>();
    static ServerSocket server;

    public static void main(String[] args) throws IOException {
        server = new ServerSocket(1234);
        ServerGUI serverGUI = new ServerGUI(server, serverThreads);
        serverGUI.setVisible(true);
        
        new SuperController().getChatController().initChatroomsTableIfNotExists();

        new Thread(() -> {
            while (true) {
                try {
                    ServerThread serverThread = new ServerThread(serverGUI.getServer().accept(), serverThreads, serverGUI);
                    serverThreads.add(serverThread);
                    serverThread.start();
                } catch (IOException e) {}
            }
        }).start();

    }

    public static void clearHistoryAfterServerShutdown() {
        try {
            server.close();
        } catch (IOException e) {
        }
        SuperController s = new SuperController();
        s.clearHistory();
    }
}
