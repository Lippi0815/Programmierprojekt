package controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.ListModel;
import server.ServerGUI;
import server.ServerThread;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author t.lippert
 */
public class MessageController {

    String ENDOFSTREAM = "#*+!";
    String DELIMITER = "-&/";

    ServerThread server;
    Socket client;
    SuperController superController;
    ArrayList<ServerThread> serverThreads;
    ServerGUI serverGUI;

    int userID;

    String name;

    public MessageController(ServerThread server, ArrayList<ServerThread> serverThreads, int userID, ServerGUI serverGUI, SuperController superController) throws IOException {
        this.server = server;
        this.client = this.server.getClient();
        this.superController = superController;
        this.serverThreads = serverThreads;
        this.serverGUI = serverGUI;
        this.userID = userID;
    }

    public void communicate() throws IOException, SQLException {
        String message = readMessage();
        processMessage(message);
    }

    public String readMessage() throws IOException {
        String message = "";

        while (!message.endsWith(ENDOFSTREAM)) {
            message += (char) server.getIn().read();
        }
        return message.substring(0, message.length() - ENDOFSTREAM.length());
    }

    private void processMessage(String message) throws IOException, SQLException {
        //messageToAllClients("3Server bearbeitet neue Anfrage");
        System.out.println("Neue Anfrage: " + message);

        String chatroomID;
        Date d;
        switch (message.charAt(0)) {
            //Login-Daten prüfen
            case '0' -> {
                logServerMessage("Neue Anfrage wegen Login", "in");
                checkLogin(message.substring(1, message.length()));
            }
            //Jedem Client nach neuer Anmeldung aktuelle Userliste schicken
            case '1' -> {
                superController.getUserController().addUserDataSet(message.substring(1));
                superController.getUserChatRelationController().addUserChatRelation(userID, 1);
                DefaultListModel m = (DefaultListModel) serverGUI.getUserList().getModel();
                m.add(userID-1, message.substring(1, message.length()));
                updateUserList();
                sendChatHistory(Integer.toString(1));
            }
            //Client fordert Chatroomliste an
            case '2' ->
                sendChatroomList();
            //Client will Chatroom hinzufügen
            case '3' -> {
                addChatroom(message.substring(1));
                updateRoomList();
                sendChatroomList();
            }
            //Client will Chatroom entfernen
            case '5' -> {
                if(!"1".equals(message.substring(1))){
                    removeChatroom(message.substring(1));
                    updateRoomList();
                    sendChatroomList();
                }
                
            }
            //Client ist Chatroom beigetreten
            case '6' -> {
                chatroomID = message.substring(1, message.length());
                superController.getUserChatRelationController().addUserChatRelation(userID, Integer.parseInt(chatroomID));
                //updateChatroomUserList(chatroomID);
                sendChatHistory(chatroomID);
            }
            //Client sendet Nachricht in Chatroom
            case '8' -> {
                
                chatroomID = message.substring(1, message.length()).split(DELIMITER)[0];
                String type = message.substring(1, message.length()).split(DELIMITER)[2];
                message = message.substring(1, message.length()).split(DELIMITER)[1];
                
                System.out.println("Nachricht in Chatroom gesendet. ID: "+chatroomID+", message: "+message);
                d = new Date(System.currentTimeMillis());

                superController.getChatHistoryController().addChatHistoryDataSet(chatroomID, "[" + d + "] " + superController.getUserController().getUserName(userID) + ": " + message, type);
                ArrayList<Integer> userIDs = superController.getUserChatRelationController().getUser(chatroomID);

                sendMessageToChatroomUsers(userIDs, Integer.parseInt(chatroomID));
            }
            //Client will Chat Namen ändern
            case '9' -> {
                chatroomID = message.split(DELIMITER)[0];
                String newChatName = message.split(DELIMITER)[1];
                superController.getChatController().updateChatRoom(Integer.parseInt(chatroomID), newChatName);
                this.sendChatroomList();
            }
            //Client loggt sich aus
            case 'z' -> {
                superController.getUserChatRelationController().deleteUserChatRelation(userID);
                superController.getUserController().deleteUserDataSet(userID);
                removeClient();
                updateUserList();
                for (ServerThread s : serverThreads) {
                    s.updateUserID();
                }
            }
        }
    }

    public void sendMessage(String processed) throws IOException {
        server.getOut().write((processed + ENDOFSTREAM).getBytes("UTF-8"));
        server.getOut().flush();
    }

    private void sendMessageToAllClients(String message) throws IOException {
        for (int i = 0; i < serverThreads.size() && serverThreads.get(i) != null; i++) {
            //Nachricht an alle bereits angemeldeten Clients, dass neue nachricht gesendet wurde
            serverThreads.get(i).getOut().write((message + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i).getOut().flush();
        }
    }
    
    private void sendChatHistory(String chatroomID) throws IOException {
        ArrayList<String[]> history = superController.getChatHistoryController().getChatHistoryList(Integer.parseInt(chatroomID));
        System.out.println("Anzahl der bisherigen Nachrichten in Chat mit ID = "+chatroomID+": "+history.size());

            for (String[] message : history) {
                sendMessage(4+chatroomID+DELIMITER+message[1]+DELIMITER+message[2]);
            }
        
    }

    private void checkLogin(String s) throws IOException {
        String[] data = s.split(DELIMITER);
        if (superController.getLoginController().isLoginValid(data[0], data[1])) {
            sendMessage("y");
            System.out.println("Login Valid");
        } else if (superController.getLoginController().userExists(data[0])) {
            sendMessage("x");
            System.out.println("Login Invalid");
        } else {
            superController.getLoginController().addLoginDataSet(data[0], data[1]);
            sendMessage("y");
            System.out.println("Neuer Login hinzugefügt");
        }
    }

    private void updateUserList() throws IOException {
        for (int i = 0; i < serverThreads.size() && serverThreads.get(i) != null; i++) {
            String allClients = "";
            for (int userid = 1; userid <= serverThreads.size(); userid++) {
                if (userid - 1 != i && serverThreads.get(userid - 1) != null) {
                    allClients += superController.getUserController().getUserName(userid) + DELIMITER;
                }
            }

            //Nachricht an alle bereits angemeldeten Clients, dass neuer angemeldet ist
            String ret = allClients.length() > 0 ? allClients.substring(0, allClients.length() - DELIMITER.length()) : "";
            System.out.println("Geupdatete User-Liste für Client " + i + ": " + ret);
            serverThreads.get(i).getOut().write(("0" + ret + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i).getOut().flush();
        }
        
        DefaultListModel m = new DefaultListModel();
        m.addAll(superController.getUserController().getUserList());
        serverGUI.getUserList().setModel(m);
        
    }

    public String getChatName() {
        return this.name;
    }

    private void removeClient() {
        this.serverThreads.remove(userID - 1);
        this.server.interrupt();
    }

    private void addChatroom(String beschreibung) {
        this.superController.getChatController().addChatroom(beschreibung);

    }

    private void sendChatroomList() throws IOException {
        String ret = "";
        ArrayList<String> temp = this.superController.getChatController().getChatroomList();
        if (!temp.isEmpty()) {
            for (String s : temp) {
                ret += s + DELIMITER;
            }
            sendMessageToAllClients("2" + ret.substring(0, ret.length() - DELIMITER.length()));
        }
    }

    private void removeChatroom(String id) {
        this.superController.getChatController().removeChatroom(Integer.parseInt(id));
        
    }
    
    public void updateRoomList(){
        ((DefaultListModel)serverGUI.getRoomList().getModel()).clear();
        ((DefaultListModel)serverGUI.getRoomList().getModel()).addAll(superController.getChatController().getChatroomList());
    }

    private void sendMessageToChatroomUsers(ArrayList<Integer> userIDs, int chatroomID) throws IOException {
        String[] latestMessage = superController.getChatHistoryController().getLatestMessage(chatroomID);
        for (int i : userIDs) {
            serverThreads.get(i - 1).getOut().write(("4" + chatroomID + DELIMITER + latestMessage[0] + DELIMITER + latestMessage[1] + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i - 1).getOut().flush();
        }
    }

    private void updateChatroomUserList(String chatroomID) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void logServerMessage(String message, String direction) {
        Date d = new Date(System.currentTimeMillis());
        String prefix = "[" + Calendar.HOUR_OF_DAY + "] " + ("in".equals(direction) ? "<----" : "---->");
        serverGUI.getServerLogTextArea().append(prefix + message + "\n");
        
        //log in file
    }
    
    public void setUserID(int userID){
        this.userID = userID;
    }

    

}
