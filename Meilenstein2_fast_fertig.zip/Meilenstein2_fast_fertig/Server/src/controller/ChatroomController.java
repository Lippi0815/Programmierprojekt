package controller;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DatabaseMetaData;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author t.lippert
 */
public class ChatroomController {

    Connection chat = null;
    ChatHistoryController chatHistoryController;
    UserChatRelationController userChatRelationController;
    
    public ChatroomController(ChatHistoryController chatHistoryController, UserChatRelationController userChatRelationController) {
        this.chatHistoryController = chatHistoryController;
        this.userChatRelationController = userChatRelationController;
        initChatroomsTableIfNotExists();
    }

    public boolean openConnection() {
        try {
            this.chat = DriverManager.getConnection("jdbc:sqlite:chat.db");
            return true;
        } catch (SQLException e) {
            System.err.println("Fehler bei der Verbindung zur Datenbank: " + e.getMessage());
            return false;
        }
    }

    public boolean closeConnection() {
        try {
            if (chat != null) {
                chat.close();
            }
        } catch (SQLException e) {
            System.err.println("Fehler beim Schließen der Verbindung: " + e.getMessage());
            return false;
        }
        return true;
    }

    public boolean addChatroom(String beschreibung) {
        try {

            openConnection();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Chat ("
                    + "ID INTEGER PRIMARY KEY,"
                    + "Beschreibung TEXT"
                    + ")";
            Statement statement = chat.createStatement();
            statement.executeUpdate(createTableSQL);

            String insertQuery = "INSERT INTO Chat (Beschreibung) VALUES (?)";
            PreparedStatement preparedStatement = chat.prepareStatement(insertQuery);
            preparedStatement.setString(1, beschreibung);
            preparedStatement.executeUpdate();
            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim Hinzufügen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }
    
    public boolean updateChatRoom(int id, String newName){
        try {

            openConnection();
            DatabaseMetaData dbm = chat.getMetaData();
            ResultSet tables = dbm.getTables(null, null, "Chat", null);
            if (tables.next()) {
                String updateQuery = "UPDATE Chat SET Beschreibung = ? WHERE ID = ?";
                PreparedStatement updateStatement = chat.prepareStatement(updateQuery);
                updateStatement.setString(1, newName);
                updateStatement.setInt(2, id);
                updateStatement.executeUpdate();
            }
            closeConnection();
            return true;
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<String> getChatroomList() {
        ArrayList<String> ret = new ArrayList<String>();
        try {

            openConnection();
            DatabaseMetaData dbm = chat.getMetaData();
            ResultSet tables = dbm.getTables(null, null, "Chat", null);
            if (tables.next()) {
                Statement statement = chat.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT * FROM Chat");
                while (resultSet.next()) {
                    int id = resultSet.getInt("ID");
                    String beschreibung = resultSet.getString("Beschreibung");
                    ret.add(beschreibung);

                }
                System.out.println(ret);
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
        return ret;
    }

    public void shiftChatroomIndices(int startIndex) {
        try {
            openConnection();

            String query = "SELECT ID FROM Chat WHERE ID > " + startIndex + " ORDER BY ID ASC";
            PreparedStatement preparedStatement = chat.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int currentId = resultSet.getInt("ID");
                int newId = currentId - 1;

                String updateQuery = "UPDATE Chat SET ID = ? WHERE ID = ?";
                PreparedStatement updateStatement = chat.prepareStatement(updateQuery);
                updateStatement.setInt(1, newId);
                updateStatement.setInt(2, currentId);
                updateStatement.executeUpdate();
                
                this.chatHistoryController.updateChatroomID(Integer.toString(currentId), Integer.toString(newId));
                this.userChatRelationController.updateChatroomID(Integer.toString(currentId), Integer.toString(newId));
            }

            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim Verschieben der Chatroom-Indizes");
        }
    }

    public boolean removeChatroom(int id) {
        try {

            openConnection();
            String query = "DELETE FROM Chat WHERE ID = " + id;
            PreparedStatement preparedStatement = chat.prepareStatement(query);
            preparedStatement.executeUpdate();
            
            this.chatHistoryController.removeChatroom(id);
            shiftChatroomIndices(id);
            getChatroomList();
            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim entfernen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }

    public void getChatroomDescription(String ID) {
        try {

            openConnection();
            Statement statement = chat.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Chat WHERE ID = " + ID);

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String beschreibung = resultSet.getString("Beschreibung");
                System.out.println("ID: " + id + ", Beschreibung: " + beschreibung);
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }

    public boolean deleteChatroomsTable() {
        try {

            openConnection();
            String createTableSQL = "DROP TABLE Chat";
            Statement statement = chat.createStatement();
            statement.executeUpdate(createTableSQL);

            System.out.println("Chatroom Tabelle gelöscht");
            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim löschen der Tabelle: " + e.getMessage());
            return false;
        }
        return true;
    }

    public boolean initChatroomsTableIfNotExists() {
        return !getChatroomList().isEmpty() ? true : addChatroom("MainChat");
    }
}
