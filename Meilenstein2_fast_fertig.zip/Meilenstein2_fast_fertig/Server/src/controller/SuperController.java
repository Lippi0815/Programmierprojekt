package controller;


import java.sql.SQLException;

public class SuperController {
    ChatroomController chatController;
    ChatHistoryController chatHistoryController;
    LoginController loginController;
    UserChatRelationController userChatRelationController;
    UserController userController;
    
    public SuperController(){
        
        this.chatHistoryController = new ChatHistoryController();
        this.userChatRelationController = new UserChatRelationController();
        
        this.userController = new UserController(userChatRelationController);
        this.chatController = new ChatroomController(chatHistoryController, userChatRelationController);
        
        
        this.loginController = new LoginController();
        
        
    }

    
    public boolean closeConnections(){
        if(chatController.closeConnection() && chatHistoryController.closeConnection() && loginController.closeConnection() && userChatRelationController.closeConnection()){
            return true;
        }
        return false;
    }
    
    public ChatroomController getChatController(){
        return chatController;
    }

    public ChatHistoryController getChatHistoryController() {
        return chatHistoryController;
    }

    public LoginController getLoginController() {
        return loginController;
    }

    public UserChatRelationController getUserChatRelationController() {
        return userChatRelationController;
    }
    
    public UserController getUserController() {
        return userController;
    }

    public void clearHistory() {
        getChatController().deleteChatroomsTable();
        getChatHistoryController().deleteChatHistoryTable();
        getUserChatRelationController().deleteUserChatRelationTable();
        getUserController().deleteUsersTable();
        getLoginController().getLoginList();
        getLoginController().deleteLoginTable();
    }
    
    
    
}