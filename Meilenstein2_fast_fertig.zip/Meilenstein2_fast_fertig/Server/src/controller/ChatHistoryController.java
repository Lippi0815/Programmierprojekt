package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



public class ChatHistoryController {
    Connection history;
    
    public ChatHistoryController(){
        this.history = null;
    }
    
    public boolean openConnection(){
        try{
            if (history != null) {
                    history.close();
                }
            this.history = DriverManager.getConnection("jdbc:sqlite:history.db");
            return true;
        } catch (SQLException e){
            return false;
        }
        
    }
    
    public boolean closeConnection(){
            try {
                if (history != null) {
                    history.close();
                }
            } catch (SQLException e) {
                System.err.println("Fehler beim Schließen der ChatHistory Datenbankverbindung: " + e.getMessage());
                return false;
            }
            return true;
    }
    
    public boolean addChatHistoryDataSet(String chatID, String content, String type){
        try{
            openConnection();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Message (" +
                "ID INTEGER PRIMARY KEY," +
                "ChatID INTEGER," +
                "Content TEXT," +
                "Type TEXT" +
            ")";
            Statement statement = history.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO Message (ChatID, Content, Type) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = history.prepareStatement(insertQuery);
            preparedStatement.setString(1, chatID);
            preparedStatement.setString(2, content);
            preparedStatement.setString(3, type);
            preparedStatement.executeUpdate();
            
            System.out.println("Nachricht hinzugefügt");
            closeConnection();
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }
    
    
    public boolean removeChatroom(int id) {
        try {

            openConnection();
            String query = "DELETE FROM Message WHERE ChatID = " + id;
            PreparedStatement preparedStatement = history.prepareStatement(query);
            preparedStatement.executeUpdate();
            closeConnection();
            System.out.println("Erfolg beim entfernen in ChatHistory");
        } catch (SQLException e) {
            System.out.println("Fehler beim entfernen in ChatHistory");
            return false;
        }
        return true;
    }
    
    public boolean updateChatroomID(String oldChatroomID, String newChatroomID){
        System.out.println("Start updateChatID Methode: oldChatroomID = "+oldChatroomID+", newChatroomID:"+newChatroomID);
    
    try  {
        openConnection();
        String query = "UPDATE Message SET ChatID = ? WHERE ChatID = ?";
        PreparedStatement preparedStatement = history.prepareStatement(query);
        preparedStatement.setString(1, newChatroomID);
        preparedStatement.setString(2, oldChatroomID);
        preparedStatement.executeUpdate();
        closeConnection();
        return true;
    } catch (SQLException e) {
        System.out.println("Fehler beim Aktualisieren der ChatroomID. Grund: "+e.getCause()+" Fehlercode: "+e.getMessage());
        return false;
    }
}
    
    public ArrayList<String[]> getChatHistoryList(int chatID){
        try {
            ArrayList<String[]> ret = new ArrayList();
            openConnection();
            Statement statement = history.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Message where ChatID = "+chatID);
            String[] a;
            while (resultSet.next()) {
                String content = resultSet.getString("Content");
                String type = resultSet.getString("Type");
                a = new String[]{Integer.toString(chatID),content,type};
                ret.add(a);
            }
            closeConnection();
            return ret;
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
        return new ArrayList();
    }

    String[] getLatestMessage(int chatroomID) {
        String[] ret = new String[2];
        try {
            openConnection();
            PreparedStatement statement = history.prepareStatement("SELECT * FROM Message WHERE ChatID = ? ORDER BY ID DESC LIMIT 1");
            statement.setInt(1, chatroomID);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                ret[0] = resultSet.getString("Content");
                ret[1] = resultSet.getString("Type");
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
        return ret;
    }
    
    public boolean deleteChatHistoryTable() {
        try {

            openConnection();
            String createTableSQL = "DROP TABLE Message";
            Statement statement = history.createStatement();
            statement.executeUpdate(createTableSQL);

            System.out.println("ChatHistory Tabelle gelöscht");
            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim löschen der Tabelle: " + e.getMessage());
            return false;
        }
        return true;
    }
    /*
    public void getChatHistoryList(){
        try {
            Statement statement = history.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Benutzer");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String benutzername = resultSet.getString("Benutzername");
                String passwort = resultSet.getString("Passwort");
                boolean locked = resultSet.getBoolean("Locked");
                System.out.println("ID: " + id + ", Benutzername: " + benutzername + ", Passwort: " + passwort + ", Locked: "+locked);
            }
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }
           */     

}
