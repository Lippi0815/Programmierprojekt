/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package server;

import controller.SuperController;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author t.lippert
 */
public class Server {

    static ArrayList<ServerThread> serverThreads = new ArrayList<ServerThread>();
    static ServerSocket[] server = new ServerSocket[1];

    public static void main(String[] args) throws IOException {
        server[0] = new ServerSocket(1234);
        ServerGUI serverGUI = new ServerGUI(server, serverThreads);
        serverGUI.setVisible(true);
        

        new Thread(() -> {
            while (true) {
                while (!server[0].isClosed()) {
                    try {
                        ServerThread serverThread = new ServerThread(server[0].accept(), serverThreads, serverGUI);
                        serverThreads.add(serverThread);
                        serverThread.start();
                    } catch (IOException e) {

                    }
                }
            }
        }).start();

    }

    public static void clearHistoryAfterServerShutdown() {
        try {
            server[0].close();
        } catch (IOException e) {
        }
        SuperController s = new SuperController();
        s.clearHistory();
    }
}
