package server;


import controller.MessageController;
import controller.SuperController;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerThread extends Thread{
    Socket client;
    SuperController superController;
    DataInputStream in;
    DataOutputStream out;
    ArrayList<ServerThread> serverThreads;
    MessageController m;
    ServerGUI serverGUI;
    
    public ServerThread(Socket client, ArrayList<ServerThread> serverThreads, ServerGUI serverGUI) throws IOException {
        this.client = client;
        this.superController = new SuperController();
        this.serverThreads = serverThreads;
        this.serverGUI = serverGUI;
    }
    
    @Override
    public void run(){
        
        try {
            m = new MessageController(this, serverThreads, serverThreads.indexOf(this)+1, serverGUI);
            while(true){
                m.communicate();
            }
            
        } catch (IOException ex) {} catch (SQLException ex) {}
    }

    public Socket getClient() {
        return client;
    }

    public SuperController getSuperController() {
        return superController;
    }

    public DataInputStream getIn() throws IOException {
        return new DataInputStream(client.getInputStream());
    }

    public DataOutputStream getOut() throws IOException {
        return new DataOutputStream(client.getOutputStream());
    }
    
    public String getChatName(){
        return m.getChatName();
    }
    
    public Socket getCLient(){
        return this.client;
    }
}
