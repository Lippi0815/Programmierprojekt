package controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import javax.swing.DefaultListModel;
import server.ServerGUI;
import server.ServerThread;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author t.lippert
 */
public class MessageController {

    String ENDOFSTREAM = "#*+!";
    String DELIMITER = "-&/";

    ServerThread server;
    Socket client;
    SuperController superController;
    ArrayList<ServerThread> serverThreads;
    ServerGUI serverGUI;

    int userID;

    String name;

    public MessageController(ServerThread server, ArrayList<ServerThread> serverThreads, int userID, ServerGUI serverGUI) throws IOException {
        this.server = server;
        this.client = this.server.getClient();
        this.superController = this.server.getSuperController();
        this.serverThreads = serverThreads;
        this.serverGUI = serverGUI;
        this.userID = userID;
    }

    public void communicate() throws IOException, SQLException {
        String message = readMessage();
        processMessage(message);
    }

    public String readMessage() throws IOException {
        String message = "";

        while (!message.endsWith(ENDOFSTREAM)) {
            message += (char) server.getIn().read();
        }
        return message.substring(0, message.length() - ENDOFSTREAM.length());
    }

    private void processMessage(String message) throws IOException, SQLException {
        //messageToAllClients("3Server bearbeitet neue Anfrage");
        System.out.println("Neue Anfrage: " + message);

        String chatroomID;
        Date d;
        switch (message.charAt(0)) {
            //Login-Daten prüfen
            case '0' -> {
                logServerMessage("Neue Anfrage wegen Login", "in");
                checkLogin(message.substring(1, message.length()));
            }
            //Jedem Client nach neuer Anmeldung aktuelle Userliste schicken
            case '1' -> {
                
                superController.getUserController().addUserDataSet(message.substring(1, message.length()));
                superController.getUserChatRelationController().addUserChatRelation(userID, 1);
                updateUserList();
            }
            //Client fordert Chatroomliste an
            case '2' ->
                sendChatroomList();
            //Client will Chatroom hinzufügen
            case '3' -> {
                addChatroom(message.substring(1));
                sendChatroomListToAllClients();
            }
            //Client will Chatroom entfernen
            case '5' -> {
                removeChatroom(message.substring(1));
                sendChatroomListToAllClients();
            }
            //Client ist Chatroom beigetreten
            case '6' -> {
                chatroomID = message.substring(1, message.length());
                superController.getUserChatRelationController().addUserChatRelation(userID, Integer.parseInt(chatroomID));
                //updateChatroomUserList(chatroomID);
            }
            case '7' -> {
                //Client sendet Nachricht in MainChat
                d = new Date(System.currentTimeMillis());
                superController.getChatHistoryController().addChatHistoryDataSet("1", "[" + d + "] " + superController.getUserController().getUserName(userID) + ": " + message.substring(1, message.length()));
                sendMessageToAllClients("3" + superController.getChatHistoryController().getLatestMessage(1));
            }
            //Client sendet Nachricht in Chatroom
            case '8' -> {
                chatroomID = message.substring(1, message.length()).split(DELIMITER)[0];
                message = message.substring(1, message.length()).split(DELIMITER)[1];
                d = new Date(System.currentTimeMillis());

                superController.getChatHistoryController().addChatHistoryDataSet(chatroomID, "[" + d + "] " + superController.getUserController().getUserName(userID) + ": " + message);
                ArrayList<Integer> userIDs = superController.getUserChatRelationController().getUser(chatroomID);
                sendMessageToChatroomUsers(userIDs, Integer.parseInt(chatroomID));
            }

            case 'z' -> {
                superController.getUserController().deleteUserDataSet(userID);
                superController.getUserChatRelationController().deleteUserChatRelation(userID);
                removeClient();
                updateUserList();
            }
        }
    }

    private void sendMessage(String processed) throws IOException {
        //messageToAllClients("3Server sendet Antwort auf neue Anfrage");
        server.getOut().write((processed + ENDOFSTREAM).getBytes("UTF-8"));
        server.getOut().flush();
    }

    private void sendMessageToAllClients(String message) throws IOException {
        for (int i = 0; i < serverThreads.size() && serverThreads.get(i) != null; i++) {
            //Nachricht an alle bereits angemeldeten Clients, dass neue nachricht gesendet wurde
            serverThreads.get(i).getOut().write((message + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i).getOut().flush();
        }
    }

    private void checkLogin(String s) throws IOException {
        String[] data = s.split(DELIMITER);
        if (superController.getLoginController().isLoginValid(data[0], data[1])) {
            sendMessage("y");
        } else if (superController.getLoginController().userExists(data[0])) {
            sendMessage("x");
        } else {
            superController.getLoginController().addLoginDataSet(data[0], data[1]);
            sendMessage("y");
        }
    }

    private void updateUserList() throws IOException {
        System.out.println(serverThreads);
        for (int i = 0; i < serverThreads.size() && serverThreads.get(i) != null; i++) {
            String allClients = "";
            for (int userid = 1; userid <= serverThreads.size(); userid++) {
                if (userid - 1 != i && serverThreads.get(userid - 1) != null) {
                    allClients += superController.getUserController().getUserName(userid) + DELIMITER;
                }
            }

            //Nachricht an alle bereits angemeldeten Clients, dass neuer angemeldet ist
            String ret = allClients.length() > 0 ? allClients.substring(0, allClients.length() - DELIMITER.length()) : "";
            System.out.println("Geupdatete User-Liste für Client " + i + ": " + ret);
            serverThreads.get(i).getOut().write(("0" + ret + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i).getOut().flush();
        }
        /*
        DefaultListModel m = new DefaultListModel();
        for (int userid = 1; userid <= serverThreads.size(); userid++) {
                if (serverThreads.get(userid - 1) != null) {
                    m.addElement(superController.getUserController().getUserName(userid));
                }
            }
        serverGUI.getUserList().setModel(m);
        */
    }

    public String getChatName() {
        return this.name;
    }

    private void removeClient() {
        this.serverThreads.set(userID - 1, null);
        this.server.interrupt();
    }

    private void addChatroom(String beschreibung) {
        this.superController.getChatController().addChatroom(beschreibung);

    }

    private void sendChatroomList() throws IOException {
        String ret = "";
        ArrayList<String> temp = this.superController.getChatController().getChatroomList();
        if (temp.size() > 0) {
            for (String s : temp) {
                ret += s + DELIMITER;
            }
            sendMessage("2" + ret.substring(0, ret.length() - DELIMITER.length()));
        } else {
            System.out.println("Chatroomlist leer");
        }

    }

    private void sendChatroomListToAllClients() throws IOException {
        String ret = "";
        ArrayList<String> temp = this.superController.getChatController().getChatroomList();
        if (temp.size() > 0) {
            for (String s : temp) {
                ret += s + DELIMITER;
            }
            System.out.println("Updated chatroomlist: "+ret);
            sendMessageToAllClients("2" + ret.substring(0, ret.length() - DELIMITER.length()));
        } else {
            System.out.println("Chatroomlist leer");
        }
    }

    private void removeChatroom(String id) {
        this.superController.getChatController().removeChatroom(Integer.parseInt(id));
    }

    private void sendMessageToChatroomUsers(ArrayList<Integer> userIDs, int chatroomID) throws IOException {
        String latestMessage = superController.getChatHistoryController().getLatestMessage(chatroomID);
        for (int i : userIDs) {
            serverThreads.get(i - 1).getOut().write(("4" + chatroomID + DELIMITER + latestMessage + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i - 1).getOut().flush();
        }
    }

    private void updateChatroomUserList(String chatroomID) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void logServerMessage(String message, String direction) {
        Date d = new Date(System.currentTimeMillis());
        serverGUI.getServerLogTextArea().append("[" + Calendar.HOUR_OF_DAY + "] " + ("in".equals(direction) ? "<----" : "---->") + message + "\n");
    }

}
