/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package client;

import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author t.lippert
 */
public class Client {

    static Controller controller;
    public static void main(String[] args) throws IOException {
        Socket server = new Socket("localhost", 1234);
        controller = new Controller(server);
        controller.start();
        controller.login();
    }
    
}
