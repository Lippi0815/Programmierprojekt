/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import client.Controller;

/**
 *
 * @author t.lippert
 */
public class GUIController {
    ClientGUI client;
    LoginUI login;
    Controller controller;
    
    public GUIController(Controller controller){
        this.controller = controller;
        client = new ClientGUI(controller);
        login = new LoginUI(controller);
    }

    public ClientGUI getClientGUI() {
        return client;
    }

    public LoginUI getLoginGUI() {
        return login;
    }
    
    
    
    
    
    
    
}
