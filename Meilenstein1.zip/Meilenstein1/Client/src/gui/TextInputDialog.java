/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class TextInputDialog {

    public static String openWindowAndGetText() {
        JFrame frame = new JFrame();
        JTextField textField = new JTextField();
        JButton button = new JButton("OK");

        // Layout-Manager setzen (hier BorderLayout verwenden)
        frame.setLayout(new BorderLayout());

        // ActionListener für den Button hinzufügen
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Methode aufrufen, um den Inhalt des Textfelds zu erhalten
                String textFieldContent = textField.getText();

                // Ausgabe des Textfeldinhalts (kann in der Konsole überprüft werden)
                System.out.println("Textfeldinhalt im Fenster: " + textFieldContent);

                // Das Fenster schließen
                frame.dispose();
            }
        });

        // Panel erstellen und den Layout-Manager für das Panel setzen
        JPanel panel = new JPanel(new FlowLayout());

        // Komponenten zum Panel hinzufügen
        panel.add(textField);
        panel.add(button);

        // Das Panel im Norden des Frames platzieren (oben)
        frame.add(panel, BorderLayout.NORTH);

        // JFrame-Eigenschaften setzen
        frame.setSize(300, 120);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null); // Zentriere das Fenster auf dem Bildschirm
        frame.setVisible(true);

        // Warte, bis das Fenster geschlossen wurde
        while (frame.isVisible()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Rückgabe des Textfeldinhalts
        return textField.getText();
    }
}
