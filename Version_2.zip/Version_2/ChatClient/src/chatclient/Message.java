/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatclient;

/**
 *
 * @author t.lippert
 */
public class Message {
    String user, date;
    Content content;

    public Message(String user, Content content, String date) {
        this.user = user;
        this.content = content;
        this.date = date;
    }
    
    @Override
    public String toString(){
        return user+" ("+date+"): "+content;
    }

    public Content getContent() {
        return content;
    }
    
    
    
}

class Content {
    String type;
    byte[] content;
    public Content(String type, byte[] content){
        this.type = type;
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public byte[] getContent() {
        return content;
    }
    
}
