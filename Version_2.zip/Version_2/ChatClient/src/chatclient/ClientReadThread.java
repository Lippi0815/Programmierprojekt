package chatclient;


import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;



public class ClientReadThread extends Thread {
    
    String ENDOFSTREAM = "#*+!";
    String DELIMITER = "-&/";
    
    Socket server;
    DataInputStream in;
    ClientWriteThread w;
    ChatClientUI ui;
    boolean running = true;
    
    public ClientReadThread(Socket server, ChatClientUI ui) throws IOException{
        this.server = server;
        this.in = new DataInputStream(server.getInputStream());
        this.ui = ui;
    }
    
    public void run(){
        while(running){
            try {
                String message = readMessage();
                System.out.println(processMessage(message));
            } catch (IOException ex) {}
        }
    }
    
    public void logOff() throws IOException{
        this.interrupt();
    }
    
    public String readMessage() throws IOException {
    System.out.println("Client liest Nachricht vom Server");
    String message = "";
    
    while (!message.endsWith(ENDOFSTREAM)) {
        message += (char) in.read();
    }
    return message.substring(0, message.length() - ENDOFSTREAM.length());
}

    private String processMessage(String message) throws IOException {
        System.out.println("Client bearbeitet Nachricht vom Server");
        String ret = "";
        JList myList;
        DefaultListModel listModel;
        switch(message.charAt(0)){
            case '0':
                //Wir bekommen Liste aller Clients
                myList = (JList) ((JScrollPane)ui.getJTabbedPane1().getComponentAt(0)).getViewport().getView();
                listModel = (DefaultListModel)myList.getModel();
                for(String user : (message.substring(1, message.length())).split(DELIMITER)){
                    listModel.addElement(user);
                }
                ret = "Liste angemeldeter Clients: "+String.join("; ", (message.substring(1, message.length())).split(DELIMITER));
                break;
            case '1':
                //Wir bekommen den Namen eines neu angemeldeten Clients
                myList = (JList) ((JScrollPane)ui.getJTabbedPane1().getComponentAt(0)).getViewport().getView();
                listModel = (DefaultListModel)myList.getModel();
                String newUser = message.substring(1, message.length());
                listModel.addElement(newUser);
                ret = "Neu angemeldeter Client mit folgendem Index: "+message.substring(1, message.length());
                break;
            case '2':
                //Wir bekommen die Liste aller Chatrooms
                myList = (JList) ((JScrollPane)ui.getJTabbedPane1().getComponentAt(1)).getViewport().getView();
                listModel = new DefaultListModel();
                for(String chatroom : (message.substring(1, message.length())).split(DELIMITER)){
                    listModel.addElement(chatroom);
                }
                myList.setModel(listModel);
                break;
            case '3':
                // Benutzeroberfläche aktualisieren
                ui.updateUIBasedOnMessage(message.substring(1, message.length()));
                ret = "Neue Nachricht: "+message.substring(1, message.length());
                break;
            //Nachricht empfangen
            case '4':
                message = message.substring(1);
                String[] content = message.split(DELIMITER);
                ui.chatrooms[Integer.parseInt(content[0])].getChatArea().append(content[1]+"\n");
                break;
            case 'x':
                //Meldung, dass Login fehlgeschlagen
                this.ui.login.loginFail();
                break;
            case 'y':
                //Meldung, dass Login erfolgreich
                this.ui.loggedIn = true;
                this.ui.login.loginSuccess();
                break;
        }
        return ret;
    }
    
    public void setClientWriteThread(ClientWriteThread w){
        this.w = w;
    }
}
