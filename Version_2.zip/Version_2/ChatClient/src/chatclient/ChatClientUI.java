package chatclient;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Scanner;

import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;

public class ChatClientUI extends javax.swing.JFrame {

    static String ENDOFSTREAM = "#*+!";
    static String DELIMITER = "-&/";
    static Socket server;
    static boolean loggedIn;
    static ClientReadThread r;
    static ClientWriteThread w;
    static ChatClientUI ui;
    static ChatRoom[] chatrooms = new ChatRoom[1000000000];
    
    static LoginUI login;

    public ChatClientUI() {
        initComponents();
    }

    public static void main(String args[]) throws IOException {

        //verbindung zum server erstellen
        server = new Socket("localhost", 1234);

        //Oberfläche des Client verborgen starten 
        ui = new ChatClientUI();

        //anlegen und starten der Lese- und SchreibeThreads
        r = new ClientReadThread(server, ui);
        w = new ClientWriteThread(server);
        r.setClientWriteThread(w);
        w.setClientReadThread(r);
        r.start();
        w.start();

        //Login-Oberfläche Starten
        loginToChatRooms(ui);

        if (loggedIn) {
            ui.update();
            //wenn Login Beendet, dann wird die Client-Oberfläche sichtbar
            ui.setVisible(true);
            System.out.println("Starten der beiden ClientThreads");
        }

    }

    public static void loginToChatRooms(ChatClientUI ui) {
        //Erstellung der Login-Oberfläche
        login = new LoginUI(ui);
        login.setVisible(true);

        //warten, bis sie sich schließt
        while (login.isActive()) {
            continue;
        }
    }

    //schließt die beiden streams und anschließend das Fenster
    static public void logOff() throws IOException {
        //benachrichtigt server, dass sich der Client abmeldet und schließt anschließend den outputstream
        w.logOff();
        //schließt den InputStream
        r.running = false;
        r.logOff();
        //schließt die chatoberfläche
        ui.dispose();
    }

    public void updateUIBasedOnMessage(String message) {
        //Anfügen der neuen Nachricht an den bisherigen Hauptchat
        serverMessageTextArea.append(message + "\n");
    }

    void setLoggedIn(boolean b) {
        this.loggedIn = true;
    }

    Socket getServer() {
        return this.server;
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        messageTextField = new javax.swing.JTextField();
        chatroomTextField = new javax.swing.JTextField();
        sendMessageButton = new javax.swing.JButton();
        serverMessageTextAreaScrollPane = new javax.swing.JScrollPane();
        serverMessageTextArea = new javax.swing.JTextArea();
        logoffButton = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        userListScrollPane = new javax.swing.JScrollPane();
        userList = new javax.swing.JList<>();
        chatroomListScrollPane = new javax.swing.JScrollPane();
        chatroomList = new javax.swing.JList<>();
        controllerComboBox = new javax.swing.JComboBox<>(new String[]{"Chatroom erstellen", "Chatroom umbenennen", "Chatroom löschen", "Chatroom beitreten"});
        controllerButton = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        userList.setModel(new javax.swing.DefaultListModel<String>());

        chatroomList.setModel(new javax.swing.DefaultListModel<String>());

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {

    @Override
    public void windowClosing(WindowEvent e) {
        int confirm = JOptionPane.showOptionDialog(
             null, "Möchtest du die Anwendung wirklich beenden?", 
             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
             JOptionPane.QUESTION_MESSAGE, null, null, null);
        if (confirm == 0) {
            try {
                logOff();
            } catch (IOException ex) {
                Logger.getLogger(ChatClientUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
});

        messageTextField.setToolTipText("Bitte die zu sendende Nachricht eingeben");
        sendMessageButton.setText("send Message");
        sendMessageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendMessageButtonActionPerformed(evt);
            }
        });

        serverMessageTextArea.setColumns(20);
        serverMessageTextArea.setRows(5);
        serverMessageTextArea.setEditable(false);
        serverMessageTextAreaScrollPane.setViewportView(serverMessageTextArea);

        logoffButton.setText("Log Off");
        logoffButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoffButtonActionPerformed(evt);
            }
        });

        userListScrollPane.setViewportView(userList);

        jTabbedPane1.addTab("Benutzer", userListScrollPane);

        chatroomListScrollPane.setViewportView(chatroomList);

        jTabbedPane1.addTab("Chatrooms", chatroomListScrollPane);

        controllerButton.setText("OK");
        controllerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    controllerButtonActionPerformed(evt);
                } catch (IOException ex) {}
            }
        });

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
getContentPane().setLayout(layout);
layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(serverMessageTextAreaScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addComponent(messageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(sendMessageButton)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(logoffButton)
                                        .addContainerGap())
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(controllerComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(chatroomTextField)) // Neues Textfeld hinzugefügt
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(controllerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addContainerGap(92, Short.MAX_VALUE))))
);
layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(serverMessageTextAreaScrollPane)
                                .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(79, 79, 79)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(controllerComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(controllerButton))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED) // Neuer Abstand eingefügt
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(chatroomTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)) // Neues Textfeld hinzugefügt
                                        .addGap(148, 148, 148)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(messageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(sendMessageButton)
                                                .addComponent(logoffButton))))
                        .addContainerGap(149, Short.MAX_VALUE))
);

pack();
    }// </editor-fold>                        

    private void sendMessageButtonActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            w.messageAllClients(messageTextField.getText());
        } catch (IOException ex) {
            Logger.getLogger(ChatClientUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void controllerButtonActionPerformed(java.awt.event.ActionEvent evt) throws IOException {
        switch ((String) controllerComboBox.getSelectedItem()) {
            case ("Chatroom erstellen"):
                w.sendAddChatroomQuery(chatroomTextField.getText().replace(" ", ""));
                break;
            case ("Chatroom umbenennen"):
                break;
            case ("Chatroom löschen"):
                w.sendRemoveChatroomQuery(chatroomList.getSelectedIndex());
                break;
            case ("Chatroom beitreten"):
                ChatRoom c = new ChatRoom(chatroomList.getSelectedIndex(), w);
                c.setVisible(true);
                c.setTitle(chatroomList.getSelectedValue());
                chatrooms[chatroomList.getSelectedIndex()] = c;
                w.sendMessage("6"+chatroomList.getSelectedIndex());
                break;
        }

    }

    private void logoffButtonActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            logOff();
        } catch (IOException ex) {
        }
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton sendMessageButton;
    private javax.swing.JButton logoffButton;
    private javax.swing.JButton controllerButton;
    private javax.swing.JComboBox<String> controllerComboBox;
    private javax.swing.JList<String> userList;
    private javax.swing.JList<String> chatroomList;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane serverMessageTextAreaScrollPane;
    private javax.swing.JScrollPane userListScrollPane;
    private javax.swing.JScrollPane chatroomListScrollPane;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea serverMessageTextArea;
    private javax.swing.JTextField messageTextField;
    private javax.swing.JTextField chatroomTextField;
    // End of variables declaration                   

    public JTabbedPane getJTabbedPane1() {
        return this.jTabbedPane1;
    }

    private void update() throws IOException {
        w.sendChatroomListQuery();
    }
}
