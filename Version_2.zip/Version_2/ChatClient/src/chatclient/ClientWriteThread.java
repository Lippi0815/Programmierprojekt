package chatclient;



import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author t.lippert
 */
public class ClientWriteThread extends Thread{
    Socket server;
    DataOutputStream out;
    String ENDOFSTREAM = "#*+!";
    String DELIMITER = "-&/";
    ClientReadThread r;
    
    public ClientWriteThread(Socket server) throws IOException{
        this.server = server;
        out = new DataOutputStream(server.getOutputStream());
    }
    
    public void run(){
        
    }

    void logOff() throws IOException {
        
        //############
        out.write(("z"+ENDOFSTREAM).getBytes("UTF-8"));
        out.close();
        this.interrupt();
    }
    
    public void messageAllClients(String message) throws IOException{
        out.write(("2"+message+ENDOFSTREAM).getBytes("UTF-8"));
        out.flush();
    }
    
    public void setClientReadThread(ClientReadThread r){
        this.r = r;
    }
    
    public void sendChatroomListQuery() throws IOException{
        out.write(("2"+ENDOFSTREAM).getBytes("UTF-8"));
        out.flush();
    }

    void sendAddChatroomQuery(String s) throws IOException {
        out.write(("3"+s+ENDOFSTREAM).getBytes("UTF-8"));
        out.flush();
    }

    void sendRemoveChatroomQuery(int selectedIndex) throws IOException {
        System.out.println(selectedIndex);
        out.write(("5"+(selectedIndex+1)+ENDOFSTREAM).getBytes("UTF-8"));
        out.flush();
    }
    
    void sendMessageIntoChatroom(int chatroomID, String message) throws IOException{
        out.write(("7"+chatroomID+DELIMITER+message+ENDOFSTREAM).getBytes("UTF-8"));
        out.flush();
    }
    
    void sendMessage(String message) throws IOException{
        out.write((message+ENDOFSTREAM).getBytes("UTF-8"));
        out.flush();
    }
}
