
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author t.lippert
 */
public class MessageController {

    String ENDOFSTREAM = "#*+!";
    String DELIMITER = "-&/";

    ServerThread server;
    Socket client;
    SuperController superController;
    ArrayList<ServerThread> serverThreads;
    int userID;

    String name;

    public MessageController(ServerThread server, ArrayList<ServerThread> serverThreads, int userID) throws IOException {
        this.server = server;
        this.client = this.server.getClient();
        this.superController = this.server.getSuperController();
        this.serverThreads = serverThreads;
        this.userID = userID;
    }

    final void communicate() throws IOException {
        String message = readMessage();
        processMessage(message);
    }

    public String readMessage() throws IOException {
        messageToAllClients("3Server empfängt neue Anfrage");
        String message = "";

        while (!message.endsWith(ENDOFSTREAM)) {
            message += (char) server.getIn().read();
        }
        return message.substring(0, message.length() - ENDOFSTREAM.length());
    }

    private void processMessage(String message) throws IOException {
        messageToAllClients("3Server bearbeitet neue Anfrage");
        String ret = "";
        String chatroomID;
        switch (message.charAt(0)) {
            //Login-Daten prüfen
            case '0':
                checkLogin(message.substring(1, message.length()));
                break;
            //Jedem Client update der Userliste schicken
            case '1':
                superController.getUserController().addUserDataSet(message.substring(1, message.length()));
                notifyAfterNewLogOn(message.substring(1, message.length()));
                break;
            //Client fordert Chatroomliste an
            case '2':
                sendChatroomList(message.substring(1, message.length()));
                break;
            //Client will Chatroom hinzufügen
            case '3':
                addChatroom(message.substring(1));
                sendChatroomListToAllClients(message.substring(1, message.length()));
                break;
            //Client will Chatroom hinzufügen
            case '5':
                removeChatroom(message.substring(1));
                sendChatroomListToAllClients(message.substring(1, message.length()));
                break;
            //Client ist Chatroom beigetreten
            case '6':
                chatroomID = message.substring(1, message.length());
                superController.getUserChatRelationController().addUserChatRelation(Integer.toString(userID), chatroomID);
                //updateChatroomUserList(chatroomID);
                break;
            //Client sendet Nachricht in Chatroom
            case '7':
                chatroomID = message.substring(1, message.length()).split(DELIMITER)[0];
                message = message.substring(1, message.length()).split(DELIMITER)[1];
                Date d = new Date(System.currentTimeMillis());
                
                superController.getChatHistoryController().addChatHistoryDataSet(chatroomID, "["+d+"] "+superController.getUserController().getUserName(userID)+": "+message);
                ArrayList<Integer> userIDs = superController.getUserChatRelationController().getUser(chatroomID);
                sendMessageToChatroomUsers(userIDs, Integer.parseInt(chatroomID));
                break;
            case 'z':
                removeClient();
                break;
        }
    }

    private void sendMessage(String processed) throws IOException {
        messageToAllClients("3Server sendet Antwort auf neue Anfrage");
        server.getOut().write((processed + ENDOFSTREAM).getBytes("UTF-8"));
        server.getOut().flush();
    }

    private void checkLogin(String s) throws IOException {
        String[] data = s.split(DELIMITER);
        if (superController.getLoginController().isLoginValid(data[0], data[1])) {
            sendMessage("y");
        } else if (superController.getLoginController().userExists(data[0])) {
            sendMessage("x");
        } else {
            superController.getLoginController().addLoginDataSet(data[0], data[1]);
            sendMessage("y");
        }
    }

    private void notifyAfterNewLogOn(String chatname) throws IOException {
        String allClients = "";
        for (int i = 0; i < serverThreads.size(); i++) {
            if (i != userID-1 && serverThreads.get(i) != null) {
                allClients += superController.getUserController().getUserName(i+1) + DELIMITER;
                //Nachricht an alle bereits angemeldeten Clients, dass neuer angemeldet ist
                serverThreads.get(i).getOut().write(("1" + chatname + ENDOFSTREAM).getBytes("UTF-8"));
                serverThreads.get(i).getOut().flush();
            }
        }

        //Nachricht mit Liste aller bereits angemeldeten Clients
        if (allClients.length() > 0) {
            sendMessage("0" + allClients.substring(0, allClients.length() - DELIMITER.length()));
        }
    }

    private void messageToAllClients(String message) throws IOException {
        for (int i = 0; i < serverThreads.size() && serverThreads.get(i) != null; i++) {
            //Nachricht an alle bereits angemeldeten Clients, dass neue nachricht gesendet wurde
            serverThreads.get(i).getOut().write((message + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i).getOut().flush();
        }
    }

    String getChatName() {
        return this.name;
    }

    private void removeClient() {
        this.serverThreads.set(userID-1, null);
        this.server.interrupt();
    }

    private void addChatroom(String beschreibung) {
        this.superController.getChatController().addChatroom(beschreibung);

    }

    private void sendChatroomList(String substring) throws IOException {
        String ret = "";
        ArrayList<String> temp = this.superController.getChatController().getChatroomList();
        if (temp.size() > 0) {
            for (String s : temp) {
                ret += s + DELIMITER;
            }
            sendMessage("2"+ret.substring(0, ret.length() - DELIMITER.length()));
        } else {
            System.out.println("Chatroomlist leer");
        }

    }

    private void sendChatroomListToAllClients(String substring) throws IOException {
        String ret = "";
        ArrayList<String> temp = this.superController.getChatController().getChatroomList();
        if (temp.size() > 0) {
            for (String s : temp) {
                ret += s + DELIMITER;
            }
            messageToAllClients("2"+ret.substring(0, ret.length() - DELIMITER.length()));
        } else {
            System.out.println("Chatroomlist leer");
        }
    }

    private void removeChatroom(String id) {
        this.superController.getChatController().removeChatroom(Integer.parseInt(id));
    }

    private void sendMessageToChatroomUsers(ArrayList<Integer> userIDs, int chatroomID) throws IOException {
        String latestMessage = superController.getChatHistoryController().getLatestMessage(chatroomID);
        for(int i : userIDs){
            serverThreads.get(i-1).getOut().write(("4"+chatroomID+DELIMITER+latestMessage + ENDOFSTREAM).getBytes("UTF-8"));
            serverThreads.get(i-1).getOut().flush();
        }
    }

    private void updateChatroomUserList(String chatroomID) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
