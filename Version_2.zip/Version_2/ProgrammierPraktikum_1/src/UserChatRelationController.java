
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author t.lippert
 */
public class UserChatRelationController {
    Connection userChatRelation = null;
    
    public UserChatRelationController(){

    }
    
    public boolean openConnection(){
        try{
            this.userChatRelation = DriverManager.getConnection("jdbc:sqlite:userchatrelation.db");
            return true;
        } catch (SQLException e){
            return false;
        }
    }
    
    public boolean closeConnection(){
            try {
                if (userChatRelation != null) {
                    userChatRelation.close();
                }
            } catch (SQLException e) {
                return false;
            }
            return true;
    }
    
    public boolean addUserChatRelation(String userID, String chatroomID){
        try{
            openConnection();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS UserChatRelations (" +
                "ID INTEGER PRIMARY KEY," +
                "UserID TEXT," +
                "ChatroomID TEXT" +
            ")";
            Statement statement = userChatRelation.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO UserChatRelations (UserID, ChatroomID) VALUES (?, ?)";
            PreparedStatement preparedStatement = userChatRelation.prepareStatement(insertQuery);
            preparedStatement.setString(1, userID);
            preparedStatement.setString(2, chatroomID);
            preparedStatement.executeUpdate();
            
            closeConnection();
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen einer neuen UserChatRelation");
            return false;
        }
        return true;
    }
    
    public boolean removeUserChatRelation(String userID, String chatroomID){
        try{
            openConnection();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS UserChatRelations (" +
                "ID INTEGER PRIMARY KEY," +
                "UserID TEXT," +
                "ChatroomID TEXT," +
            ")";
            Statement statement = userChatRelation.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String query = "DELETE FROM UserChatRelations WHERE UserID = " + userID + "AND ChatroomID = " + chatroomID;
            PreparedStatement preparedStatement = userChatRelation.prepareStatement(query);
            preparedStatement.executeUpdate();
            closeConnection();
        } catch (SQLException e){
            return false;
        }
        return true;
    }
    
    public void getUserChatRelationList(){
        try {
            openConnection();
            Statement statement = userChatRelation.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM UserChatRelations");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String user = resultSet.getString("Beschreibung");
                String beschreibung = resultSet.getString("Beschreibung");
                System.out.println("ID: " + id + ", Beschreibung: " + beschreibung);
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }

    ArrayList<Integer> getUser(String chatroomID) {
        ArrayList<Integer> ret = new ArrayList<Integer>();
        try {
            openConnection();
            Statement statement = userChatRelation.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM UserChatRelations WHERE ChatroomID = "+chatroomID);
            while(resultSet.next()){
                ret.add(resultSet.getInt("UserID"));
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
        return ret;
    
    }
    
    public boolean deleteUserChatRelationTable() {
        try {

            openConnection();
            String createTableSQL = "DROP TABLE UserChatRelations";
            Statement statement = userChatRelation.createStatement();
            statement.executeUpdate(createTableSQL);

            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim löschen der Tabelle: " + e.getMessage());
            return false;
        }
        return true;
    }
}
