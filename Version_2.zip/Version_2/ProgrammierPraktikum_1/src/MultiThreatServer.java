
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Scanner;

public class MultiThreatServer {

    static ArrayList<ServerThread> serverThreads = new ArrayList<ServerThread>();
    static ServerSocket server;

    public static void main(String args[]) throws IOException {

        server = new ServerSocket(1234);

        new Thread(() -> {
            Scanner s = new Scanner(System.in);
            while (true) {
                String input = s.next();
                if ("Shutdown".equals(input)) {
                    clearHistoryAfterServerShutdown();
                    System.exit(0);
                }
            }
        }).start();

        while (true) {
            try{
                ServerThread serverThread = new ServerThread(server.accept(), serverThreads);
            serverThreads.add(serverThread);
            serverThread.start();
            } catch (IOException e){
                
            }
            
        }

    }

    public static void clearHistoryAfterServerShutdown() {
        try{
            server.close();
        }catch(IOException e){}
        SuperController s = new SuperController();
        s.clearHistory();
    }
}
