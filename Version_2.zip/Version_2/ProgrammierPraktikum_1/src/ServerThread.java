
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerThread extends Thread{
    Socket client;
    SuperController superController;
    DataInputStream in;
    DataOutputStream out;
    ArrayList<ServerThread> serverThreads;
    MessageController m;
    public ServerThread(Socket client, ArrayList<ServerThread> serverThreads) throws IOException {
        this.client = client;
        this.superController = new SuperController();
        this.serverThreads = serverThreads;
        
    }
    
    @Override
    public void run(){
        
        try {
            m = new MessageController(this, serverThreads, serverThreads.indexOf(this)+1);
            while(true){
                m.communicate();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Socket getClient() {
        return client;
    }

    public SuperController getSuperController() {
        return superController;
    }

    public DataInputStream getIn() throws IOException {
        return new DataInputStream(client.getInputStream());
    }

    public DataOutputStream getOut() throws IOException {
        return new DataOutputStream(client.getOutputStream());
    }
    
    public String getChatName(){
        return m.getChatName();
    }
}
