import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class ChatHistoryController {
    Connection history;
    
    public ChatHistoryController(){
        this.history = null;
    }
    
    public boolean openConnection(){
        try{
            this.history = DriverManager.getConnection("jdbc:sqlite:history.db");
            return true;
        } catch (SQLException e){
            return false;
        }
        
    }
    
    public boolean closeConnection(){
            try {
                if (history != null) {
                    history.close();
                    System.out.println("ChatHistroy Datenbankverbindung geschlossen.");
                }
            } catch (SQLException e) {
                System.err.println("Fehler beim Schließen der ChatHistory Datenbankverbindung: " + e.getMessage());
                return false;
            }
            return true;
    }
    
    public boolean addChatHistoryDataSet(String chatID, String content){
        try{
            openConnection();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Message (" +
                "ID INTEGER PRIMARY KEY," +
                "ChatID INTEGER," +
                "Content TEXT" +
            ")";
            Statement statement = history.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO Message (ChatID, Content) VALUES (?, ?)";
            PreparedStatement preparedStatement = history.prepareStatement(insertQuery);
            preparedStatement.setString(1, chatID);
            preparedStatement.setString(2, content);
            preparedStatement.executeUpdate();
            
            System.out.println("Nachricht hinzugefügt");
            closeConnection();
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }
    
    public void getChatHistoryList(){
        try {
            openConnection();
            Statement statement = history.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Message");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String userID = resultSet.getString("UserID");
                String chatID = resultSet.getString("ChatID");
                String content = resultSet.getString("Content");
                System.out.println("ID: " + id + ", UserID: " + userID + ", ChatID: " + chatID+ ", Content: " + content);
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }

    String getLatestMessage(int chatroomID) {
        String ret = "";
        try {
            openConnection();
            PreparedStatement statement = history.prepareStatement("SELECT Content FROM Message WHERE ChatID = ? ORDER BY ID DESC LIMIT 1");
            statement.setInt(1, chatroomID);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                ret = resultSet.getString("Content");
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
        return ret;
    }
    
    public boolean deleteChatHistoryTable() {
        try {

            openConnection();
            String createTableSQL = "DROP TABLE Message";
            Statement statement = history.createStatement();
            statement.executeUpdate(createTableSQL);

            System.out.println("Chatroom Tabelle gelöscht");
            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim löschen der Tabelle: " + e.getMessage());
            return false;
        }
        return true;
    }
                

}
