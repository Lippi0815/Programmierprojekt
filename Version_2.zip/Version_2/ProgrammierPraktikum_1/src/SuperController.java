
import java.sql.SQLException;

public class SuperController {
    ChatroomController chatController;
    ChatHistoryController chatHistoryController;
    LoginController loginController;
    UserChatRelationController userChatRelationController;
    UserController userController;
    
    public SuperController(){
        this.chatController = new ChatroomController();
        this.chatHistoryController = new ChatHistoryController();
        this.loginController = new LoginController();
        this.userChatRelationController = new UserChatRelationController();
        this.userController = new UserController();
    }

    
    public boolean closeConnections(){
        if(chatController.closeConnection() && chatHistoryController.closeConnection() && loginController.closeConnection() && userChatRelationController.closeConnection()){
            return true;
        }
        return false;
    }
    
    public ChatroomController getChatController(){
        return chatController;
    }

    public ChatHistoryController getChatHistoryController() {
        return chatHistoryController;
    }

    public LoginController getLoginController() {
        return loginController;
    }

    public UserChatRelationController getUserChatRelationController() {
        return userChatRelationController;
    }
    
    public UserController getUserController() {
        return userController;
    }

    void clearHistory() {
        getChatController().deleteChatroomsTable();
        getChatHistoryController().deleteChatHistoryTable();
        getUserChatRelationController().deleteUserChatRelationTable();
        getUserController().deleteUsersTable();
    }
    
    
    
}