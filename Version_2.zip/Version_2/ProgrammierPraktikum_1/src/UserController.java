import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author t.lippert
 */
public class UserController {
    
    Connection login = null;

    public UserController(){
        

    }
    
    public boolean openConnection(){
        try{
            this.login = DriverManager.getConnection("jdbc:sqlite:user.db");
            System.out.println("Verbindung zur Datenbank hergestellt.");
            return true;
        } catch (SQLException e){
            System.err.println("Fehler bei der Verbindung zur Datenbank: " + e.getMessage());
            return false;
        }
    }
    
    public boolean closeConnection(){
            try {
                if (login != null) {
                    login.close();
                    System.out.println("Login Datenbankverbindung geschlossen.");
                }
            } catch (SQLException e) {
                System.err.println("Fehler beim Schließen der Verbindung: " + e.getMessage());
                return false;
            }
            return true;
    }
    
    public boolean addUserDataSet(String user){
        try{
            System.out.println("User "+user+"soll Datenbank hinzugefügt werden");
            openConnection();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Benutzername (" +
                "ID INTEGER PRIMARY KEY," +
                "Name TEXT" +
            ")";
            Statement statement = login.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO Benutzername (Name) VALUES (?)";
            PreparedStatement preparedStatement = login.prepareStatement(insertQuery);
            preparedStatement.setString(1, user);
            preparedStatement.executeUpdate();
            closeConnection();
            System.out.println(user+" wurde userdatenbank hinzugefügt");
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }
    
    public ArrayList<String> getUserList(){
        ArrayList<String> ret = new ArrayList<String>();
        try {
            openConnection();
            Statement statement = login.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Benutzername");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String benutzername = resultSet.getString("Name");
                ret.add(benutzername);
            }
            closeConnection();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
        return ret;
    }
    
    public String getUserName(int id){
        try {
            System.out.println(getUserList());
            openConnection();
            Statement statement = login.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Benutzername WHERE ID = "+id);
            String ret = "";
            if(resultSet.next()){
                ret = resultSet.getString("Name");
                System.out.println("ID: "+id+", name: "+ret);
            }
            closeConnection();
            return ret;
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
        return "";
    }

    
    public boolean deleteUsersTable() {
        try {

            openConnection();
            String createTableSQL = "DROP TABLE Benutzername";
            Statement statement = login.createStatement();
            statement.executeUpdate(createTableSQL);

            closeConnection();
        } catch (SQLException e) {
            System.out.println("Fehler beim löschen der Tabelle: " + e.getMessage());
            return false;
        }
        return true;
    }
}
