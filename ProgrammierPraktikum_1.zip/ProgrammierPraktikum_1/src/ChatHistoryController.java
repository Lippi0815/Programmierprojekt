import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class ChatHistoryController {
    Connection history;
    
    public ChatHistoryController(){
        this.history = null;
    }
    
    public boolean openConnection(){
        try{
            this.history = DriverManager.getConnection("jdbc:sqlite:history.db");
            return true;
        } catch (SQLException e){
            return false;
        }
        
    }
    
    public boolean closeConnection(){
            try {
                if (history != null) {
                    history.close();
                    System.out.println("ChatHistroy Datenbankverbindung geschlossen.");
                }
            } catch (SQLException e) {
                System.err.println("Fehler beim Schließen der ChatHistory Datenbankverbindung: " + e.getMessage());
                return false;
            }
            return true;
    }
    
    public boolean addLoginDataSet(String userID, String chatID, String time, String content){
        try{
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Message (" +
                "ID INTEGER PRIMARY KEY," +
                "UserID INTEGER," +
                "ChatID INTEGER" +
                "Time TEXT" +
                "Content TEXT" +
            ")";
            Statement statement = history.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO Message (UserID, ChatID, Time, Content) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = history.prepareStatement(insertQuery);
            preparedStatement.setString(1, userID);
            preparedStatement.setString(2, chatID);
            preparedStatement.setString(3, time);
            preparedStatement.setString(4, content);
            preparedStatement.executeUpdate();
            
            System.out.println("Nachricht hinzugefügt");
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }
    
    public void getFullChatHistory(){
        try {
            Statement statement = history.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Message");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String userID = resultSet.getString("UserID");
                String chatID = resultSet.getString("ChatID");
                String time = resultSet.getString("Time");
                String content = resultSet.getString("Content");
                System.out.println("ID: " + id + ", UserID: " + userID + ", ChatID: " + chatID + ", Time: " + time + ", Content: " + content);
            }
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }
                

}
