
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author t.lippert
 */
public class UserChatRelationController {
    Connection userChatRelation;
    
    public UserChatRelationController(){
        userChatRelation = null;

    }
    
    public boolean openConnection(){
        try{
            this.userChatRelation = DriverManager.getConnection("jdbc:sqlite:userchatrelation.db");
            return true;
        } catch (SQLException e){
            return false;
        }
    }
    
    public boolean closeConnection(){
            try {
                if (userChatRelation != null) {
                    userChatRelation.close();
                }
            } catch (SQLException e) {
                return false;
            }
            return true;
    }
    
    public boolean addChatDataSet(String user, String chatroomID){
        try{
            String createTableSQL = "CREATE TABLE IF NOT EXISTS UserChatRelations (" +
                "ID INTEGER PRIMARY KEY," +
                "UserID TEXT," +
                "ChatroomID TEXT," +
            ")";
            Statement statement = userChatRelation.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO UserChatRelations (User, ChatroomID) VALUES (?, ?)";
            PreparedStatement preparedStatement = userChatRelation.prepareStatement(insertQuery);
            preparedStatement.setString(1, user);
            preparedStatement.setString(2, chatroomID);
            preparedStatement.executeUpdate();
            
            System.out.println("Neuer Chatroom hinzugefügt");
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen eines neuen Chatrooms");
            return false;
        }
        return true;
    }
    
    public void getUserChatRelationList(){
        try {
            Statement statement = userChatRelation.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM UserChatRelations");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String user = resultSet.getString("Beschreibung");
                String beschreibung = resultSet.getString("Beschreibung");
                System.out.println("ID: " + id + ", Beschreibung: " + beschreibung);
            }
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }
}
