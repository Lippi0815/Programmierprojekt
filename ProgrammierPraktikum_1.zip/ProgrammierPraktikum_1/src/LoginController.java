
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author t.lippert
 */
public class LoginController {
    
    Connection login;

    public LoginController(){
        login = null;

    }
    
    public boolean openConnection(){
        try{
            this.login = DriverManager.getConnection("jdbc:sqlite:login.db");
            System.out.println("Verbindung zur Datenbank hergestellt.");
            return true;
        } catch (SQLException e){
            System.err.println("Fehler bei der Verbindung zur Datenbank: " + e.getMessage());
            return false;
        }
    }
    
    public boolean closeConnection(){
            try {
                if (login != null) {
                    login.close();
                    System.out.println("Login Datenbankverbindung geschlossen.");
                }
            } catch (SQLException e) {
                System.err.println("Fehler beim Schließen der Verbindung: " + e.getMessage());
                return false;
            }
            return true;
    }
    
    public boolean addLoginDataSet(String user, String password){
        try{
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Benutzer (" +
                "ID INTEGER PRIMARY KEY," +
                "Benutzername TEXT," +
                "Passwort TEXT" +
            ")";
            Statement statement = login.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO Benutzer (Benutzername, Passwort) VALUES (?, ?)";
            PreparedStatement preparedStatement = login.prepareStatement(insertQuery);
            preparedStatement.setString(1, user);
            preparedStatement.setString(2, password);
            preparedStatement.executeUpdate();
            
            System.out.println("Benutzer hinzugefügt");
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }
    
    public void getLogins(){
        try {
            Statement statement = login.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Benutzer");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String benutzername = resultSet.getString("Benutzername");
                String passwort = resultSet.getString("Passwort");
                System.out.println("ID: " + id + ", Benutzername: " + benutzername + ", Passwort: " + passwort);
            }
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }
    
    public boolean isLoginValid(String user, String password){
        String query = "SELECT COUNT(*) AS count FROM Benutzer WHERE Benutzername = ? AND Passwort = ?";

        try (PreparedStatement preparedStatement = login.prepareStatement(query)) {

            preparedStatement.setString(1, user);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                return count > 0;
            }
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankabfrage: " + e.getMessage());
        }

        return false;
    }
}
