
import java.sql.SQLException;

public class SuperController {
    ChatroomController chatController;
    ChatHistoryController chatHistoryController;
    LoginController loginController;
    UserChatRelationController userChatRelationController;
    
    public SuperController(){
        this.chatController = new ChatroomController();
        this.chatHistoryController = new ChatHistoryController();
        this.loginController = new LoginController();
        this.userChatRelationController = new UserChatRelationController();
    }
    
    public boolean openConnections(){
            if(chatController.openConnection() && chatHistoryController.openConnection() && loginController.openConnection() && userChatRelationController.openConnection()){
                return true;
            } else {
                closeConnections();
                return false;
            }
    }
    
    public boolean closeConnections(){
        if(chatController.closeConnection() && chatHistoryController.closeConnection() && loginController.closeConnection() && userChatRelationController.closeConnection()){
            return true;
        }
        return false;
    }
    
    public ChatroomController getChatController(){
        return chatController;
    }

    public ChatHistoryController getChatHistoryController() {
        return chatHistoryController;
    }

    public LoginController getLoginController() {
        return loginController;
    }

    public UserChatRelationController getUserChatRelationController() {
        return userChatRelationController;
    }
    
    
    
}