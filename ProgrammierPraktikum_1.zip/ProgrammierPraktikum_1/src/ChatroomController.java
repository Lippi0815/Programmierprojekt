
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author t.lippert
 */
public class ChatroomController {
    Connection chat;
    
    public ChatroomController(){
        chat = null;

    }
    
    public boolean openConnection(){
        try{
            this.chat = DriverManager.getConnection("jdbc:sqlite:chat.db");
            System.out.println("Verbindung zur Datenbank hergestellt.");
            return true;
        } catch (SQLException e){
            System.err.println("Fehler bei der Verbindung zur Datenbank: " + e.getMessage());
            return false;
        }
    }
    
    public boolean closeConnection(){
            try {
                if (chat != null) {
                    chat.close();
                    System.out.println("Login Datenbankverbindung geschlossen.");
                }
            } catch (SQLException e) {
                System.err.println("Fehler beim Schließen der Verbindung: " + e.getMessage());
                return false;
            }
            return true;
    }
    
    public boolean addChatroom(String beschreibung){
        try{
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Chat (" +
                "ID INTEGER PRIMARY KEY," +
                "Beschreibung TEXT," +
            ")";
            Statement statement = chat.createStatement();
            statement.executeUpdate(createTableSQL);
        
            String insertQuery = "INSERT INTO Chat (Beschreibung) VALUES (?)";
            PreparedStatement preparedStatement = chat.prepareStatement(insertQuery);
            preparedStatement.setString(1, beschreibung);
            preparedStatement.executeUpdate();
            
            System.out.println("Neuer Chatroom hinzugefügt");
        } catch (SQLException e){
            System.out.println("Fehler beim Hinzufügen eines neuen SQL-Datensatzes");
            return false;
        }
        return true;
    }
    
    public void getChatroomList(){
        try {
            Statement statement = chat.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Chat");

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String beschreibung = resultSet.getString("Beschreibung");
                System.out.println("ID: " + id + ", Beschreibung: " + beschreibung);
            }
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }
    
    public void getChatroomDescription(String ID){
        try {
            Statement statement = chat.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Chat WHERE ID = "+ID);

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String beschreibung = resultSet.getString("Beschreibung");
                System.out.println("ID: " + id + ", Beschreibung: " + beschreibung);
            }
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankoperation: " + e.getMessage());
        }
    }
}