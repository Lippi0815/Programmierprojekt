/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatroomserver;
import java.util.*;
/**
 *
 * @author lukas
 */
public class ChatRoom {
    Client[] members;
    String name;
    String id;
    public ArrayList<Message> log;
    
    public ChatRoom(String Name){
        this.name=name;
        this.members = new Client[0];
        //tbr
        this. id = "1";
        
    }
    public void addMember(Client c){
        Client[]rep = new Client[members.length +1];
        for(int i = 0; i<members.length;i++){
            rep[i] = members[i];
        }
        rep[members.length]= c;
        members = rep;
    }
    public void messageAll(String text){
        for(Client c : members){
            if(c.current == this)
                c.write(text);
        }
    }
}
