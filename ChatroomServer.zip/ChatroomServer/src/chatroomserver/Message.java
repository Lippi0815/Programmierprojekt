/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatroomserver;

/**
 *
 * @author lukas
 */
public class Message {
    Client author;
    String content;
    //DateTime time;
    public Message(Client c, String content){
        this. content = content;
        this.author = c;
    }
}
