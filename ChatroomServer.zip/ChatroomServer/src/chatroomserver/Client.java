/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatroomserver;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author lukas
 */
public class Client extends Thread {
    String name;
    String pw;
    Socket c;
    InputStream in;
    OutputStream out;
    String id;
    ChatRoom current;
    boolean isAdmin;
    public Client(Socket c){
        try{
        this.c = c;
        this. in = c.getInputStream();
        this.out = c.getOutputStream();
        run();
      }
      catch(Exception e){}  
    }
    public void run(){
        try{
            if(read().equals(1)){
            out.write(1);
            out.flush();
            String username = read();
            this.name = username;
            write("1");
            String pw1 = read();
            this.pw = pw1;
            ChatroomServer.notifyAll(this);
        }
        while(true){
            byte[] input = in.readAllBytes();
                String data = bts(input);
                switch(data.charAt(0)){
                    case '0':
                        current.log.add(new Message(this,data.substring(1)));
                        current.messageAll(data.substring(1));
                        break;
                    case '1':
                        break;
                    case '2':
                        break;
                }
        }
        }catch(Exception e){}     
        
   }
    public void write(String data){
        try {
            byte[] bytes = stb(data);
            out.write(bytes);
            out.flush();
        } catch (IOException ex) {}
    }
    public String read(){
        try {
            byte[] b = in.readAllBytes();
            return bts(b);
        } catch (IOException ex) {
    }
        return "9";
    }
    public byte[] stb(String input){
        byte[] ofTheKing = new byte[input.length()];
        for(int i = 0; i<input.length();i++){
            ofTheKing[i]= (byte) input.charAt(i);
        }
        return ofTheKing;
    }
   public String bts(byte[] input){
       String toMonkeyIsland = "";
       for(byte b : input){
            toMonkeyIsland += (char) b;
        }
       return toMonkeyIsland;
   }
}
