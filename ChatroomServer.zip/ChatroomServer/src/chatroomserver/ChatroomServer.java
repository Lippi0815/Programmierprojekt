package chatroomserver;
import java.net.*;
import java.io.*;
import java.util.*;

public class ChatroomServer {
    public static Client[] clients = new Client[0];
    public static void main(String[] args) {
        clients = new Client[0];
        String ip = "89.247.172.1";
        //tbr
        ChatRoom test = new ChatRoom("test");
        try{
        ServerSocket listener = new ServerSocket(1234);
        while(true){
            Client c = new Client(listener.accept());
            AddClient(c);
            //tbr
            c.current = test;
            test.addMember(c);
            //tbr
            c.id = Integer.toString(clients.length);
        }
        }   
        catch(Exception e){}
    }
    public static void AddClient(Client c){
        Client[] rep = new Client[clients.length +1];
        for(int i = 0; i< clients.length;i++){
            rep[i] = clients[i];
        }
        rep[clients.length]= c;
        clients = rep;
    }
    public static void notifyAll(Client c){
        String allOnlineMembers ="";
        for(Client e: clients)
            if(!e.id.equals(c.id)){
                allOnlineMembers += e.name+" ist online\n";
                e.write(c.name+ " ist jetzt online");
            }
        c.write(allOnlineMembers);
    }
    
}
